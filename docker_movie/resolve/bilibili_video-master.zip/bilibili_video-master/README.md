# bilibili_video

仿bilibili的播放器

原作者：<a href="https://github.com/jdyzm">@jdyzm</a> TA的主站：<a href="http://jdyzm.cn/">jdyzm.cn</a>

xiwangly修改，原作者的信息仍被保留，小改了一些东西，修复弹幕无法显示的问题，懒人式优化（免修改网站的弹幕接口URL等一些信息）……

将momo.sql导入数据库中，然后访问`http://您的域名/v3/install/`，填入正确的数据库信息，之后就可以访问`http://您的域名/?url=视频直链`使用了
