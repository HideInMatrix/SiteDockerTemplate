<div id="footer">Copyright &copy; <span style="color:#FF5200">www.bo15</span><span style="color:#0065FF">.Cn</span> , good end <a href="http://bbs.aglua.com" target="_blank">二次云解析</a></div>
