# flarum-ganuonglachanh-search
Support search in Discussion Title

Install
```
composer require ganuonglachanh/flarum-ext-search
```

https://discuss.flarum.org/d/6126-search-in-discussion-title


https://github.com/ganuonglachanh/flarum-ganuonglachanh-search