/*
 *
 *  This file is part of fof/drafts.
 *
 *  Copyright (c) 2021 FriendsOfFlarum.
 *
 *  For the full copyright and license information, please view the LICENSE.md
 *  file that was distributed with this source code.
 *
 */

import DraftsListState from './DraftsListState';

export const states = {
  DraftsListState: DraftsListState,
};
