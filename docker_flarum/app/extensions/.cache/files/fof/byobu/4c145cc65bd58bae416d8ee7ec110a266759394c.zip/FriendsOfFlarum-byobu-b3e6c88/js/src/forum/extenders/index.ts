import SettingsPage from './SettingsPage';
import Discussion from './Discussion';
import User from './User';

export default () => {
  Discussion();
  SettingsPage();
  User();
};
