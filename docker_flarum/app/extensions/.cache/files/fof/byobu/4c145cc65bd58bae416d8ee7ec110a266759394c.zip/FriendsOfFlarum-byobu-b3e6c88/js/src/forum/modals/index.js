import AddRecipientModal from './AddRecipientModal';

export const modals = {
  AddRecipientModal: AddRecipientModal,
};
