import PrivateDiscussionComposer from './PrivateDiscussionComposer';
import PrivateDiscussionList from './PrivateDiscussionList';

export const discussions = {
  PrivateDiscussionComposer: PrivateDiscussionComposer,
  PrivateDiscussionList: PrivateDiscussionList,
};
