import UploadPage from './UploadPage';

export const components = {
  UploadPage,
};
