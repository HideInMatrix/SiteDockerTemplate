<img src="{@url}" title="{@base_name}" alt="{@base_name}"/>
