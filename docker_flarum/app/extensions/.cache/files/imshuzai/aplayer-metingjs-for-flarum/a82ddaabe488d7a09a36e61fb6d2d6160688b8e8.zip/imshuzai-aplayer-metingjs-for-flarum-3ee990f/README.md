# Aplayer and MetingJS for Flarum

Install:

> composer require imshuzai/aplayer-metingjs-for-flarum

\[metingjs server="netease/tencent" id="song id/playlist id/album id" type="song/playlist/album"]

\[aplayer name="song name" artist="artist name" url="song url" cover="cover url(optional)" lrc="lrc url(optinoal)"]
