import {Static} from 'mithril';

declare global {
  const m: Static;
}
