import app from 'flarum/forum/app';

app.initializers.add('nyu8-email-filter', () => {});
