module.exports = require('flarum-webpack-config')({
    useExtensions: ['fof-components'],
});
