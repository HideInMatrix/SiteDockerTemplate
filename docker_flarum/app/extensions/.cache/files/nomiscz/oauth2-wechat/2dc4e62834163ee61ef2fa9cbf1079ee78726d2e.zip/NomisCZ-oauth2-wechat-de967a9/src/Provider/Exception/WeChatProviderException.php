<?php

namespace NomisCZ\OAuth2\Client\Provider\Exception;

class WeChatProviderException extends \League\OAuth2\Client\Provider\Exception
{

}