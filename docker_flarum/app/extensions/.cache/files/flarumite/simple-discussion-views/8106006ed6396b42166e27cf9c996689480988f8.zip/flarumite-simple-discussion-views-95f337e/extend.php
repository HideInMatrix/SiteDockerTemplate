<?php

/*
 * This file is part of flarumite/simple-discussion-views.
 *
 * Copyright (c) 2020 Flarumite.
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Flarumite\DiscussionViews;

use Flarum\Api\Controller;
use Flarum\Api\Serializer\DiscussionSerializer;
use Flarum\Database\AbstractModel;
use Flarum\Discussion\Event\Saving;
use Flarum\Discussion\Filter\DiscussionFilterer;
use Flarum\Discussion\Search\DiscussionSearcher;
use Flarum\Extend;

return [
    (new Extend\Frontend('forum'))
        ->css(__DIR__.'/resources/less/forum.less')
        ->js(__DIR__.'/js/dist/forum.js'),

    (new Extend\Frontend('admin'))
        ->js(__DIR__.'/js/dist/admin.js'),

    new Extend\Locales(__DIR__.'/resources/locale'),

    (new Extend\Event())
        ->listen(Saving::class, Listeners\SaveDiscussionFromModal::class),

    (new Extend\ApiSerializer(DiscussionSerializer::class))
        ->attribute('views', function (DiscussionSerializer $serializer, AbstractModel $discussion) {
            return $discussion->view_count;
        })
        ->attributes(AddAttributesBasedOnPermission::class),

    (new Extend\ApiController(Controller\ShowDiscussionController::class))
        ->prepareDataForSerialization(Listeners\AddDiscussionViewHandler::class),

    (new Extend\ApiController(Controller\ListDiscussionsController::class))
        ->addSortField('view_count'),

    (new Extend\Settings())
        ->default('fsdv.ignore-crawlers', true),

    (new Extend\ServiceProvider())
        ->register(Provider\DiscussionViewsProvider::class),

    (new Extend\SimpleFlarumSearch(DiscussionSearcher::class))
        ->addGambit(Search\PopularFilterGambit::class),

    (new Extend\Filter(DiscussionFilterer::class))
        ->addFilter(Search\PopularFilterGambit::class),
];
